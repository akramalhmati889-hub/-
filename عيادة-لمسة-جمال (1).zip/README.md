# عيادة لمسة جمال - موقع ويب متكامل

هذا المشروع هو موقع ويب احترافي لعيادة تجميل، يتضمن واجهة مستخدم عصرية (React) وخلفية برمجية (Node.js/Express) مع قاعدة بيانات (SQLite).

## متطلبات التشغيل
يجب أن يكون لديك **Node.js** مثبتاً على جهازك.

## طريقة التشغيل محلياً (بعد فك الضغط)

1. **تثبيت المكتبات:**
   افتح مبنى الأوامر (Terminal) في مجلد المشروع وقم بتشغيل:
   ```bash
   npm install
   ```

2. **تشغيل الموقع (وضع التطوير):**
   قم بتشغيل الأمر التالي:
   ```bash
   npm run dev
   ```
   سيظهر لك رابط (غالباً `http://localhost:3000`)، قم بفتحه في المتصفح.

3. **بناء النسخة النهائية (Production):**
   إذا أردت تشغيل الموقع بشكل نهائي:
   ```bash
   npm run build
   NODE_ENV=production npm start
   ```

## ملاحظات هامة
- قاعدة البيانات مخزنة في ملف `clinic.db`.
- لوحة تحكم المواعيد موجودة في الزر العائم أسفل يسار الموقع.
- الموقع يستخدم **Tailwind CSS** للتصميم و **Motion** للتحريك.

---

# Lamsat Jamal Clinic - Full Website

This project is a professional beauty clinic website with a modern UI (React) and a backend (Node.js/Express) with a database (SQLite).

## Prerequisites
You need to have **Node.js** installed on your machine.

## How to run locally (after unzipping)

1. **Install Dependencies:**
   Open your terminal in the project folder and run:
   ```bash
   npm install
   ```

2. **Run the App (Development Mode):**
   Run the following command:
   ```bash
   npm run dev
   ```
   Open the provided link (usually `http://localhost:3000`) in your browser.

3. **Build for Production:**
   ```bash
   npm run build
   NODE_ENV=production npm start
   ```

## Important Notes
- The database is stored in `clinic.db`.
- The appointments dashboard is accessible via the floating button at the bottom left.
- Built with **Tailwind CSS** and **Motion**.
