import express from "express";
import { createServer as createViteServer } from "vite";
import Database from "better-sqlite3";
import path from "path";

const db = new Database("clinic.db");

// Initialize database
db.exec(`
  CREATE TABLE IF NOT EXISTS appointments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    phone TEXT NOT NULL,
    service TEXT NOT NULL,
    date TEXT NOT NULL,
    message TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )
`);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Routes
  app.post("/api/appointments", (req, res) => {
    const { name, phone, service, date, message } = req.body;
    
    if (!name || !phone || !service || !date) {
      return res.status(400).json({ error: "جميع الحقول المطلوبة يجب إكمالها" });
    }

    try {
      const stmt = db.prepare(`
        INSERT INTO appointments (name, phone, service, date, message)
        VALUES (?, ?, ?, ?, ?)
      `);
      const result = stmt.run(name, phone, service, date, message);
      res.status(201).json({ id: result.lastInsertRowid, message: "تم تسجيل الموعد بنجاح" });
    } catch (error) {
      console.error("Database error:", error);
      res.status(500).json({ error: "حدث خطأ أثناء حفظ الموعد" });
    }
  });

  app.get("/api/appointments", (req, res) => {
    try {
      const appointments = db.prepare("SELECT * FROM appointments ORDER BY created_at DESC").all();
      res.json(appointments);
    } catch (error) {
      res.status(500).json({ error: "حدث خطأ أثناء جلب المواعيد" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(process.cwd(), "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.join(process.cwd(), "dist/index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
