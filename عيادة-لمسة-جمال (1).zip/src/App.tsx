/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Menu, 
  X, 
  Phone, 
  MapPin, 
  Instagram, 
  Facebook, 
  Twitter, 
  Sparkles, 
  Zap, 
  Heart, 
  Scissors, 
  UserCheck,
  Calendar,
  ChevronLeft,
  MessageCircle
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

const services = [
  {
    title: "تنظيف البشرة",
    description: "جلسات تنظيف عميق للبشرة باستخدام أحدث الأجهزة لإزالة الشوائب وإعادة النضارة.",
    icon: <Sparkles className="w-8 h-8 text-brand-accent" />,
    image: "https://images.unsplash.com/photo-1570172619644-dfd03ed5d881?auto=format&fit=crop&w=800&q=80"
  },
  {
    title: "جلسات الليزر",
    description: "إزالة الشعر بالليزر بأحدث التقنيات العالمية الآمنة والفعالة لجميع أنواع البشرة.",
    icon: <Zap className="w-8 h-8 text-brand-accent" />,
    image: "https://images.unsplash.com/photo-1559599101-f09722fb4948?auto=format&fit=crop&w=800&q=80"
  },
  {
    title: "الفيلر والبوتوكس",
    description: "إجراءات تجميلية دقيقة لإخفاء التجاعيد وإبراز ملامح الجمال الطبيعي.",
    icon: <Heart className="w-8 h-8 text-brand-accent" />,
    image: "https://images.unsplash.com/photo-1616394584738-fc6e612e71b9?auto=format&fit=crop&w=800&q=80"
  },
  {
    title: "نحت الجسم غير الجراحي",
    description: "تقنيات حديثة لشد الجسم والتخلص من الدهون الموضعية بدون تدخل جراحي.",
    icon: <Scissors className="w-8 h-8 text-brand-accent" />,
    image: "https://images.unsplash.com/photo-1519823551278-64ac92734fb1?auto=format&fit=crop&w=800&q=80"
  },
  {
    title: "العناية بالشعر",
    description: "علاجات متطورة لمشاكل تساقط الشعر وتقويته باستخدام الميزوثيرابي والبلازما.",
    icon: <UserCheck className="w-8 h-8 text-brand-accent" />,
    image: "https://images.unsplash.com/photo-1560869713-7d0a29430803?auto=format&fit=crop&w=800&q=80"
  }
];

export default function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [formStatus, setFormStatus] = useState<'idle' | 'submitting' | 'success'>('idle');

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setIsMenuOpen(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setFormStatus('submitting');
    
    const formData = new FormData(e.currentTarget);
    const data = {
      name: formData.get('name'),
      phone: formData.get('phone'),
      service: formData.get('service'),
      date: formData.get('date'),
      message: formData.get('message'),
    };

    try {
      const response = await fetch('/api/appointments', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });

      if (response.ok) {
        setFormStatus('success');
      } else {
        const errorData = await response.json();
        alert(errorData.error || 'حدث خطأ ما');
        setFormStatus('idle');
      }
    } catch (error) {
      console.error('Error submitting form:', error);
      alert('فشل الاتصال بالخادم');
      setFormStatus('idle');
    }
  };

  const [appointments, setAppointments] = useState<any[]>([]);
  const [showDashboard, setShowDashboard] = useState(false);

  const fetchAppointments = async () => {
    try {
      const response = await fetch('/api/appointments');
      const data = await response.json();
      setAppointments(data);
      setShowDashboard(true);
    } catch (error) {
      console.error('Error fetching appointments:', error);
    }
  };

  return (
    <div className="min-h-screen">
      {/* Dashboard Modal */}
      <AnimatePresence>
        {showDashboard && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] bg-black/60 backdrop-blur-sm flex items-center justify-center p-4"
          >
            <motion.div 
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              className="bg-white rounded-[2rem] w-full max-w-4xl max-h-[80vh] overflow-hidden shadow-2xl"
            >
              <div className="p-8 border-b border-gray-100 flex justify-between items-center bg-brand-pink/30">
                <h3 className="text-2xl font-bold text-gray-900">قائمة المواعيد المسجلة</h3>
                <button onClick={() => setShowDashboard(false)} className="p-2 hover:bg-white rounded-full transition-colors">
                  <X size={24} />
                </button>
              </div>
              <div className="p-8 overflow-y-auto max-h-[calc(80vh-100px)]">
                {appointments.length === 0 ? (
                  <p className="text-center text-gray-500 py-12">لا توجد مواعيد مسجلة حتى الآن.</p>
                ) : (
                  <div className="space-y-4">
                    {appointments.map((app) => (
                      <div key={app.id} className="p-6 rounded-2xl border border-pink-50 bg-gray-50 hover:bg-pink-50/50 transition-colors">
                        <div className="flex justify-between items-start mb-2">
                          <h4 className="font-bold text-lg text-gray-900">{app.name}</h4>
                          <span className="text-xs text-gray-400">{new Date(app.created_at).toLocaleString('ar-YE')}</span>
                        </div>
                        <div className="grid md:grid-cols-3 gap-4 text-sm">
                          <div className="flex items-center gap-2 text-gray-600">
                            <Phone size={14} className="text-brand-accent" />
                            <span dir="ltr">{app.phone}</span>
                          </div>
                          <div className="flex items-center gap-2 text-gray-600">
                            <Sparkles size={14} className="text-brand-accent" />
                            <span>{app.service}</span>
                          </div>
                          <div className="flex items-center gap-2 text-gray-600">
                            <Calendar size={14} className="text-brand-accent" />
                            <span>{app.date}</span>
                          </div>
                        </div>
                        {app.message && (
                          <p className="mt-3 text-sm text-gray-500 bg-white p-3 rounded-lg border border-gray-100 italic">
                            "{app.message}"
                          </p>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-white/90 backdrop-blur-md border-b border-pink-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-20">
            <div className="flex items-center gap-2 cursor-pointer" onClick={() => scrollToSection('home')}>
              <div className="w-10 h-10 rounded-full gold-gradient flex items-center justify-center shadow-md">
                <Sparkles className="text-white w-6 h-6" />
              </div>
              <span className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-brand-gold to-brand-accent">
                لمسة جمال
              </span>
            </div>

            {/* Desktop Menu */}
            <div className="hidden md:flex items-center gap-8">
              {['home', 'about', 'services', 'booking', 'contact'].map((item) => (
                <button
                  key={item}
                  onClick={() => scrollToSection(item)}
                  className="text-gray-600 hover:text-brand-accent transition-colors font-medium capitalize"
                >
                  {item === 'home' ? 'الرئيسية' : 
                   item === 'about' ? 'من نحن' : 
                   item === 'services' ? 'خدماتنا' : 
                   item === 'booking' ? 'حجز موعد' : 'اتصل بنا'}
                </button>
              ))}
              <button 
                onClick={() => scrollToSection('booking')}
                className="bg-brand-accent text-white px-6 py-2 rounded-full hover:bg-pink-500 transition-all shadow-lg hover:shadow-pink-200"
              >
                احجزي الآن
              </button>
            </div>

            {/* Mobile Menu Toggle */}
            <div className="md:hidden">
              <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="text-gray-600">
                {isMenuOpen ? <X size={28} /> : <Menu size={28} />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        <AnimatePresence>
          {isMenuOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="md:hidden bg-white border-b border-pink-100 overflow-hidden"
            >
              <div className="px-4 pt-2 pb-6 space-y-2">
                {['home', 'about', 'services', 'booking', 'contact'].map((item) => (
                  <button
                    key={item}
                    onClick={() => scrollToSection(item)}
                    className="block w-full text-right px-4 py-3 text-gray-600 hover:bg-pink-50 rounded-lg"
                  >
                    {item === 'home' ? 'الرئيسية' : 
                     item === 'about' ? 'من نحن' : 
                     item === 'services' ? 'خدماتنا' : 
                     item === 'booking' ? 'حجز موعد' : 'اتصل بنا'}
                  </button>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>

      {/* Hero Section */}
      <section id="home" className="relative pt-20 h-screen flex items-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?auto=format&fit=crop&w=1920&q=80" 
            alt="Clinic Interior" 
            className="w-full h-full object-cover opacity-30"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-brand-pink/60 to-white/90"></div>
        </div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
            >
              <h1 className="text-5xl md:text-7xl font-bold text-gray-900 leading-tight mb-6">
                جمالكِ يبدأ <br />
                <span className="text-brand-accent">من هنا</span>
              </h1>
              <p className="text-xl text-gray-600 mb-8 max-w-lg leading-relaxed">
                في عيادة لمسة جمال، نجمع بين الخبرة الطبية وأحدث التقنيات العالمية لنمنحكِ الإطلالة التي تستحقينها.
              </p>
              <div className="flex flex-wrap gap-4">
                <button 
                  onClick={() => scrollToSection('booking')}
                  className="bg-brand-accent text-white px-8 py-4 rounded-full text-lg font-semibold shadow-xl hover:bg-pink-500 transition-all flex items-center gap-2"
                >
                  <Calendar className="w-5 h-5" />
                  احجزي موعدكِ الآن
                </button>
                <button 
                  onClick={() => scrollToSection('services')}
                  className="bg-white border-2 border-brand-gold text-brand-gold px-8 py-4 rounded-full text-lg font-semibold hover:bg-brand-gold hover:text-white transition-all"
                >
                  اكتشفي خدماتنا
                </button>
              </div>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8 }}
              className="relative hidden md:block"
            >
              <div className="w-full aspect-square rounded-full overflow-hidden border-8 border-white shadow-2xl relative z-10">
                <img 
                  src="https://images.unsplash.com/photo-1512290923902-8a9f81dc236c?auto=format&fit=crop&w=800&q=80" 
                  alt="Beauty" 
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="absolute -bottom-6 -right-6 bg-white p-6 rounded-2xl shadow-xl border border-pink-50">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center">
                    <UserCheck className="text-green-600" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">فريق طبي</p>
                    <p className="font-bold text-gray-900">متخصص ومحترف</p>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-16 items-center">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              className="relative"
            >
              <img 
                src="https://images.unsplash.com/photo-1527613426441-4da17471b66d?auto=format&fit=crop&w=800&q=80" 
                alt="Clinic Team" 
                className="rounded-3xl shadow-2xl"
                referrerPolicy="no-referrer"
              />
              <div className="absolute -top-8 -left-8 w-32 h-32 gold-gradient rounded-full opacity-20 blur-3xl"></div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <span className="text-brand-gold font-bold tracking-widest uppercase text-sm mb-4 block">من نحن</span>
              <h2 className="text-4xl font-bold text-gray-900 mb-6">رؤيتنا هي تعزيز جمالكِ الطبيعي</h2>
              <p className="text-lg text-gray-600 mb-6 leading-relaxed">
                تعتبر عيادة لمسة جمال من العيادات الرائدة في صنعاء، حيث نسعى لتقديم تجربة تجميلية فريدة تجمع بين الراحة النفسية والنتائج المذهلة.
              </p>
              <div className="space-y-4">
                {[
                  "فريق طبي متخصص ذو خبرة عالمية.",
                  "أحدث الأجهزة والتقنيات في عالم التجميل.",
                  "التزام تام بأعلى معايير النظافة والتعقيم.",
                  "خطط علاجية مخصصة لكل حالة."
                ].map((item, i) => (
                  <div key={i} className="flex items-center gap-3">
                    <div className="w-6 h-6 rounded-full bg-pink-100 flex items-center justify-center flex-shrink-0">
                      <ChevronLeft className="w-4 h-4 text-brand-accent" />
                    </div>
                    <span className="text-gray-700">{item}</span>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-24 bg-brand-pink/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">خدماتنا المتميزة</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              نقدم مجموعة متكاملة من الخدمات التجميلية والعلاجية المصممة خصيصاً لتلبية احتياجاتكِ.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                viewport={{ once: true }}
                className="bg-white rounded-3xl overflow-hidden shadow-lg hover:shadow-xl transition-all group"
              >
                <div className="h-48 overflow-hidden">
                  <img 
                    src={service.image} 
                    alt={service.title} 
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <div className="p-8">
                  <div className="mb-4">{service.icon}</div>
                  <h3 className="text-xl font-bold text-gray-900 mb-3">{service.title}</h3>
                  <p className="text-gray-600 leading-relaxed">
                    {service.description}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Booking Section */}
      <section id="booking" className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-white rounded-[3rem] shadow-2xl overflow-hidden border border-pink-50">
            <div className="grid md:grid-cols-2">
              <div className="p-12 md:p-16">
                <h2 className="text-4xl font-bold text-gray-900 mb-6">احجزي موعدكِ الآن</h2>
                <p className="text-gray-600 mb-8">
                  املئي النموذج أدناه وسيقوم فريقنا بالتواصل معكِ لتأكيد الموعد في أقرب وقت.
                </p>

                {formStatus === 'success' ? (
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="bg-green-50 text-green-700 p-8 rounded-2xl text-center"
                  >
                    <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                      <UserCheck className="w-8 h-8" />
                    </div>
                    <h3 className="text-xl font-bold mb-2">تم استلام طلبكِ بنجاح!</h3>
                    <p>سنتواصل معكِ قريباً لتأكيد الموعد.</p>
                    <button 
                      onClick={() => setFormStatus('idle')}
                      className="mt-6 text-green-700 font-bold underline"
                    >
                      إرسال طلب آخر
                    </button>
                  </motion.div>
                ) : (
                  <form onSubmit={handleSubmit} className="space-y-4">
                    <div className="grid md:grid-cols-2 gap-4">
                      <input 
                        name="name"
                        type="text" 
                        placeholder="الاسم الكامل" 
                        required
                        className="w-full px-6 py-4 rounded-xl bg-gray-50 border-none focus:ring-2 focus:ring-brand-accent outline-none"
                      />
                      <input 
                        name="phone"
                        type="tel" 
                        placeholder="رقم الهاتف" 
                        required
                        className="w-full px-6 py-4 rounded-xl bg-gray-50 border-none focus:ring-2 focus:ring-brand-accent outline-none"
                      />
                    </div>
                    <select 
                      name="service"
                      className="w-full px-6 py-4 rounded-xl bg-gray-50 border-none focus:ring-2 focus:ring-brand-accent outline-none appearance-none"
                    >
                      <option value="">اختر الخدمة</option>
                      {services.map(s => <option key={s.title} value={s.title}>{s.title}</option>)}
                    </select>
                    <input 
                      name="date"
                      type="date" 
                      required
                      className="w-full px-6 py-4 rounded-xl bg-gray-50 border-none focus:ring-2 focus:ring-brand-accent outline-none"
                    />
                    <textarea 
                      name="message"
                      placeholder="رسالة إضافية (اختياري)" 
                      rows={4}
                      className="w-full px-6 py-4 rounded-xl bg-gray-50 border-none focus:ring-2 focus:ring-brand-accent outline-none"
                    ></textarea>
                    <button 
                      type="submit"
                      disabled={formStatus === 'submitting'}
                      className="w-full bg-brand-accent text-white py-4 rounded-xl font-bold text-lg shadow-lg hover:bg-pink-500 transition-all disabled:opacity-50"
                    >
                      {formStatus === 'submitting' ? 'جاري الإرسال...' : 'تأكيد الحجز'}
                    </button>
                  </form>
                )}
              </div>
              <div className="relative hidden md:block">
                <img 
                  src="https://images.unsplash.com/photo-1512290923902-8a9f81dc236c?auto=format&fit=crop&w=800&q=100" 
                  alt="Booking" 
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-brand-accent/20"></div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-24 bg-brand-pink/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-12">
            <div className="md:col-span-1">
              <h2 className="text-3xl font-bold text-gray-900 mb-8">تواصلوا معنا</h2>
              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-full bg-white shadow-md flex items-center justify-center flex-shrink-0">
                    <MapPin className="text-brand-gold" />
                  </div>
                  <div>
                    <p className="font-bold text-gray-900">العنوان</p>
                    <p className="text-gray-600">صنعاء – اليمن، شارع حدة، عمارة الأمل</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-full bg-white shadow-md flex items-center justify-center flex-shrink-0">
                    <Phone className="text-brand-gold" />
                  </div>
                  <div>
                    <p className="font-bold text-gray-900">رقم الهاتف</p>
                    <p className="text-gray-600" dir="ltr">+967 777 000 000</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-full bg-white shadow-md flex items-center justify-center flex-shrink-0">
                    <MessageCircle className="text-brand-gold" />
                  </div>
                  <div>
                    <p className="font-bold text-gray-900">البريد الإلكتروني</p>
                    <p className="text-gray-600">info@lamsatjamal.com</p>
                  </div>
                </div>
              </div>

              <div className="mt-12 flex gap-4">
                {[Instagram, Facebook, Twitter].map((Icon, i) => (
                  <a 
                    key={i} 
                    href="#" 
                    className="w-10 h-10 rounded-full bg-white shadow-md flex items-center justify-center text-brand-accent hover:bg-brand-accent hover:text-white transition-all"
                  >
                    <Icon size={20} />
                  </a>
                ))}
              </div>
            </div>

            <div className="md:col-span-2 h-[400px] rounded-3xl overflow-hidden shadow-2xl border-4 border-white relative">
              {/* Placeholder for Map */}
              <div className="absolute inset-0 bg-gray-200 flex flex-col items-center justify-center text-gray-500">
                <MapPin size={48} className="mb-4 opacity-50" />
                <p className="text-lg font-medium">خريطة الموقع (صنعاء - اليمن)</p>
                <p className="text-sm">سيتم تحميل الخريطة التفاعلية هنا</p>
              </div>
              <iframe 
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d123123!2d44.20!3d15.35!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x1603db46176337af%3A0x86701c79ca2e896!2sSana'a%2C%20Yemen!5e0!3m2!1sen!2s!4v1234567890" 
                className="w-full h-full border-0 relative z-10 opacity-80 grayscale hover:grayscale-0 transition-all duration-500"
                allowFullScreen={true} 
                loading="lazy"
              ></iframe>
            </div>
          </div>
        </div>
      </section>

      {/* Floating Admin Button */}
      <button 
        onClick={fetchAppointments}
        className="fixed bottom-8 left-8 z-40 bg-white/80 backdrop-blur-md border border-pink-100 text-brand-accent p-4 rounded-full shadow-lg hover:bg-brand-accent hover:text-white transition-all group"
        title="لوحة التحكم"
      >
        <UserCheck size={24} />
        <span className="max-w-0 overflow-hidden group-hover:max-w-xs transition-all duration-500 whitespace-nowrap mr-0 group-hover:mr-2">
          المواعيد
        </span>
      </button>

      {/* Footer */}
      <footer className="bg-white py-12 border-t border-pink-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="flex items-center justify-center gap-2 mb-6">
            <div className="w-8 h-8 rounded-full gold-gradient flex items-center justify-center shadow-sm">
              <Sparkles className="text-white w-4 h-4" />
            </div>
            <span className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-brand-gold to-brand-accent">
              لمسة جمال
            </span>
          </div>
          <p className="text-gray-500 text-sm">
            &copy; {new Date().getFullYear()} عيادة لمسة جمال. جميع الحقوق محفوظة.
          </p>
          <p className="text-gray-400 text-xs mt-2">
            صنعاء، الجمهورية اليمنية
          </p>
        </div>
      </footer>
    </div>
  );
}
